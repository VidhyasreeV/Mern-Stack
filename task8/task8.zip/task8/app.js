console.log("inside app.js");

const http = require('http');
const todos = require('./todos');

const server = http.createServer((req, res) => {
  // if (req.url === '/todos' && req.method === 'GET') {
  //   const allTodos = todos.listTodos();
  //   res.setHeader('Content-Type', 'application/json');
  //   res.end(JSON.stringify(allTodos));
  // } 
  const { method, url } = req;


  if (req.method === 'GET') {
    if (url === '/todos') {
      const allTodos = todos.listTodos();
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(allTodos));
    } 
    else if (url.startsWith('/todos/')) {
      const todoId = url.substring(7);
      const todo = todos.getTodoById(todoId);

      if (todo) {
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(todo));
      } 
      else {
        res.writeHead(404, { 'Content-Type': 'text/plain' });
        res.end('Todo not found');
      }
    } else {
      res.writeHead(404, { 'Content-Type': 'text/plain' });
      res.end('Error');
    }
  }

  else if (req.url === '/todos' && req.method === 'POST') {
    let data = '';
    req.on('data', chunk => {
      data += chunk;
    });

    //console.log(title);


    req.on('end', () => {
      const title = JSON.parse(data).title;
      const list = JSON.parse(data).list;
      //console.log(title);
      todos.addTodo(title,list);
      res.statusCode = 200;
      res.end('Todo added successfully');
    });
  }

  else if (req.url.startsWith('/todos/') && req.method === 'DELETE') {
    const id = req.url.split('/')[2];
    const deleted = todos.deleteTodo(id);
    if (deleted) {
      res.statusCode = 200;
      res.end('Todo deleted successfully');
    } else {
      res.statusCode = 404;
      res.end('Todo not found');
    }
  }


  else if (method === 'PATCH' && url.startsWith('/todos/')) {
    const todoId = url.substring(7);

    let body = '';
    req.on('data', (chunk) => {
      body += chunk;
    });

    req.on('end', () => {
      const todoData = JSON.parse(body);
      const updatedTodo = todos.updateTodoById(todoId, todoData);

      if (updatedTodo) {
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(updatedTodo));
      } else {
        res.writeHead(404, { 'Content-Type': 'text/plain' });
        res.end('Todo not found');
      }
    });
  }

  else {
    res.statusCode = 404;
    res.end('Not found');
  }
});

server.listen(5000, () => {
  console.log('Server is running on port 5000');
});