console.log("inside todo.js");

const fs = require('fs');
const { v4: uuidv4 } = require('uuid');


var addTodo = (title,list) => {
  var todos = [];

  var todo = {
    id: uuidv4(),
    title,
    list
  };

  try {
    var todostring = fs.readFileSync('todos-data.json');
    todos = JSON.parse(todostring);
  } catch (e) {
  }

  var duplicateTodo = todos.filter((todo) => todo.title === title);

  if (duplicateTodo.length === 0) {
    todos.push(todo);
    fs.writeFileSync('todos-data.json', JSON.stringify(todos));
  }
};

var deleteTodo = (id) => {
  var todos = fetchTodos();
  var filteredTodos = todos.filter((todo) => todo.id !== id);
  saveTodos(filteredTodos);
  return todos.length !== filteredTodos.length;
};

var fetchTodos = () => {
  try {
    var todoString = fs.readFileSync('todos-data.json');
    return JSON.parse(todoString);
  } catch (e) {
    return [];
  }
};

var saveTodos = (todos) => {
  fs.writeFileSync('todos-data.json', JSON.stringify(todos));
};

var listTodos = () => {
  return fetchTodos();
};

var getTodoById = (id) => {
  var todos = fetchTodos();
  return todos.find((todo) => todo.id === id);
};

var updateTodoById = (id, updatedData) => {
  var todos = fetchTodos();
  var todoIndex = todos.findIndex((todo) => todo.id === id);

  if (todoIndex !== -1) {
    var updatedTodo = { ...todos[todoIndex], ...updatedData };
    todos[todoIndex] = updatedTodo;
    saveTodos(todos);
    return updatedTodo;
  } else {
    return null;
  }
};

module.exports = {
  addTodo,
  deleteTodo,
  listTodos,
  getTodoById,
  updateTodoById
};