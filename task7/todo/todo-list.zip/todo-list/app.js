console.log('Running app.js');
const chalk = require('chalk');
const fs = require('fs');
const _ = require('lodash');
const yargs = require('yargs');

const todos = require('./todos');

const argv = yargs.argv;
var command = argv._[0];
console.log(chalk.yellow('Running Command: ', command));

if (command === 'addTodo') {
    //console.log(argv.list)
    todos.addTodo(argv.title,argv.list);
} else if (command === 'deleteTodo') {
    var todoDeleted = todos.deleteTodo(argv.title);
    var message = todoDeleted ? 'Todo was deleted' : 'Todo not found';
    console.log(chalk.magenta(message));
} else if (command === 'readTodo') {
    var todo = todos.readTodo(argv.title);
    if (todo) {
        console.log(chalk.blue('Great! The todo was found.'));
        todos.logTodo(todo);
    } else {
        console.log(chalk.blue('Whoops! The todo was not found.'));
    }
} else if (command === 'listTodos') {
    var allTodos = todos.listTodos();
    console.log(chalk.cyan(`Printing ${allTodos.length} todo(s).`));
    allTodos.forEach((todo) => todos.logTodo(todo));
} else {
    console.log(chalk.red('Invalid command.'));
}