import React, { useState } from "react";
import TimelineTweet from "../TimelineTweet/TimelineTweet";

import { useSelector } from "react-redux";
import axios from "axios";
import {
  getStorage,
  ref,
  uploadBytesResumable,
  getDownloadURL,
} from "firebase/storage";
import app from "../../firebase";


const MainTweet = () => {
  const [tweetText, setTweetText] = useState("");

  const [tweetFile, setTweetFile] = useState(null);

  const { currentUser } = useSelector((state) => state.user);

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    setTweetFile(file);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      let fileUrl = null;
      if (tweetFile) {
        fileUrl = await uploadFile(tweetFile);
      }
      const submitTweet = await axios.post("/tweets", {
        userId: currentUser._id,
        description: tweetText,
        file: fileUrl,

      });
      window.location.reload(false);
    } catch (err) {
      console.log(err);
    }
  };
  
  const uploadFile = async (file,tweet) => {
    if (!file) return null;

    const storage = getStorage(app);
    const fileName = new Date().getTime() + file.name;
    const storageRef = ref(storage, fileName);
    const uploadTask = uploadBytesResumable(storageRef, file);

    return new Promise((resolve, reject) => {
      uploadTask.on(
        "state_changed",
        (snapshot) => {
          // Handle upload progress if needed
          const progress =
          (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
          console.log("Upload progress: " + progress + "%");
        switch (snapshot.state) {
          case "paused":
            console.log("Upload is paused");
            break;
          case "running":
            console.log("Upload is running");
            break;
          default:
            break;
        }
        },
        (error) => {
          reject(error);
        },
        async () => {
          try {
            const downloadURL = await getDownloadURL(uploadTask.snapshot.ref);
            resolve(downloadURL);
            // try {
            //   const uploadfiles = await axios.put(`/Tweet/${tweet._id}`, {
            //     file: downloadURL,
            //   });
  
            // } catch (error) {
            //   console.log(error);
            // }
          } catch (error) {
            reject(error);
          }
        }
      );
    });
  };

  return (
    <div>
      {currentUser && (
        <p className="font-bold pl-2 my-2">{currentUser.username}</p>
      )}

      <form className="border-b-2 pb-6">
        <textarea
          onChange={(e) => setTweetText(e.target.value)}
          type="text"
          placeholder="What's happening"
          maxLength={280}
          className="bg-slate-200 rounded-lg w-full p-2"
        ></textarea>
        <input
          type="file"
          accept="image/*"
          onChange={handleFileChange}
        />
        <button
          onClick={handleSubmit}
          className="bg-blue-500 text-white py-2 px-4 rounded-full ml-auto"
        >
          Tweet
        </button>
      </form>
      <TimelineTweet />
    </div>
  );
};

export default MainTweet;